package com.topjohnwu.magisk.di

val koinModules = listOf(
    applicationModule,
    networkingModule,
    databaseModule,
    repositoryModule,
    viewModelModules
)
